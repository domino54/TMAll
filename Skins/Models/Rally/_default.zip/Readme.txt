HD rally car
original model by Nadeo
refined by BiBi (january 2009)