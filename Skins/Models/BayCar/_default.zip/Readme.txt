HD Bay car
Original autor Nadeo
refined by BiBi march 2009